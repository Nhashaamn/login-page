import 'package:flutter/material.dart';

class IsText extends StatelessWidget {
  const IsText({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        Text(
          "Welcome back !",
          style: TextStyle(color: Color.fromARGB(255, 1, 55, 80), fontSize: 16),
        ),
        Text(
          "Please sign in to continue.",
          style: TextStyle(color: Color.fromARGB(255, 1, 55, 80), fontSize: 16),
        ),
      ],
    );
  }
}
