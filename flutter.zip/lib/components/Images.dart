import 'package:flutter/material.dart';

class Images extends StatelessWidget {
  final String imagepath;
  const Images({super.key, required this.imagepath});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color.fromARGB(255, 206, 198, 231),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey),
      ),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Image.asset(
          imagepath,
          height: 50,
        ),
      ),
    );
  }
}
