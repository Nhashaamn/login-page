import 'package:flutter/material.dart';
import 'package:login/pages/LoginPage.dart';
import 'package:login/pages/registerpage.dart';

class LoginOrRegister extends StatefulWidget {
  const LoginOrRegister({super.key});

  @override
  State<LoginOrRegister> createState() => _LoginOrRegisterState();
}

class _LoginOrRegisterState extends State<LoginOrRegister> {
  bool showloginpage = true;

  void tooglepage() {
    setState(() {
      showloginpage = !showloginpage;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (showloginpage) {
      return LoginPage(ontap: tooglepage);
    } else {
      return RegisterPage(
        ontap: tooglepage,
      );
    }
  }
}
