import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:login/components/Images.dart';
import 'package:login/components/IsText.dart';
import 'package:login/components/MyButton.dart';
import 'package:login/components/TextFeild.dart';

class LoginPage extends StatefulWidget {
  final Function()? ontap;
  LoginPage({super.key, required this.ontap});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final emailcontroller = TextEditingController();
  final passwordcontroller = TextEditingController();

  void signuserin() async {
    showDialog(
      context: context,
      builder: (context) {
        return const Center(
          child: CircularProgressIndicator(),
        );
      },
    );

    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: emailcontroller.text, password: passwordcontroller.text);

      Navigator.pop(context);
    } on FirebaseException catch (e) {
      Navigator.pop(context);

      if (e.code == 'user-not-found') {
        wrongemailmessage();
      } else if (e.code == 'wrong-password') {
        wrongpasswordmessage();
      }
    }
  }

  void wrongemailmessage() {
    showDialog(
      context: context,
      builder: (context) {
        return const AlertDialog(
          title: Text("email incorrect"),
        );
      },
    );
  }

  void wrongpasswordmessage() {
    showDialog(
      context: context,
      builder: (context) {
        return const AlertDialog(
          title: Text("password incorrect"),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: const Color.fromARGB(255, 186, 186, 253),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.blue),
              ),
              child: const Padding(
                padding: EdgeInsets.all(8.0),
                child: Text(
                  "Faculty Tracker",
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue),
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            const Center(
              child: Icon(
                Icons.lock,
                color: Colors.blue,
                size: 100,
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            const IsText(),
            const SizedBox(
              height: 20,
            ),
            CustomTextField(
              controller: emailcontroller,
              hintText: "email",
              obscureText: false,
            ),
            const SizedBox(
              height: 10,
            ),
            CustomTextField(
              controller: passwordcontroller,
              hintText: "password",
              obscureText: true,
            ),
            const SizedBox(
              height: 20,
            ),
            Container(
              alignment: Alignment.centerRight,
              child: const Padding(
                padding: EdgeInsets.only(right: 50),
                child: Text(
                  "Forgot password?",
                  style: TextStyle(
                      color: Color.fromARGB(255, 0, 0, 0), fontSize: 16),
                ),
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            MyButton(
              text: "Sign in",
              ontap: signuserin,
            ),
            const SizedBox(
              height: 20,
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 50),
              child: Row(
                children: [
                  Expanded(
                    child: Divider(
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    "  Or continue with  ",
                    style: TextStyle(
                        fontWeight: FontWeight.bold, color: Colors.blue),
                  ),
                  Expanded(
                    child: Divider(
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Images(
                  imagepath: "lib/assets/google.jpg",
                ),
                SizedBox(
                  width: 30,
                ),
                Images(
                  imagepath: "lib/assets/apple.jpg",
                )
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text("not a member? "),
                GestureDetector(
                  onTap: widget.ontap,
                  child: const Text(
                    "Register",
                    style: TextStyle(color: Colors.blueAccent),
                  ),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
